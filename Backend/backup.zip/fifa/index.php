<?php
// fifa/index.php - MinersHub FIFA Campaign PHP API

header("Content-Type: application/json; charset=utf-8");

$allowed_origins = [
    "http://localhost:5173",
    "https://minershub.online",
    "https://www.minershub.online",
    "https://fifa-campaign-frontend.vercel.app",
    "https://campaign.minershub.online"
];

$origin = $_SERVER["HTTP_ORIGIN"] ?? "";

if (in_array($origin, $allowed_origins, true)) {
    header("Access-Control-Allow-Origin: " . $origin);
    header("Access-Control-Allow-Credentials: true");
} else {
    header("Access-Control-Allow-Origin: *");
}

header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Authorization, X-Requested-With");

if ($_SERVER["REQUEST_METHOD"] === "OPTIONS") {
    http_response_code(204);
    exit;
}
date_default_timezone_set("UTC");

$DB_HOST = "localhost";
$DB_NAME = "minershu_fifa";
$DB_USER = "minershu_fifa";
$DB_PASS = "@FI@Fifa1234";

$JWT_SECRET = "minershub_fifa_private_secret_2026_827391";

$USERS_TABLE = "users";
$MATCHES_TABLE = "matches";
$PREDICTIONS_TABLE = "predictions";

function json_response($data, $status = 200) {
    http_response_code($status);
    echo json_encode($data);
    exit;
}

try {
    $pdo = new PDO(
        "mysql:host=$DB_HOST;dbname=$DB_NAME;charset=utf8mb4",
        $DB_USER,
        $DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]
    );
    $pdo->exec("SET time_zone = '+00:00'");
} catch (Exception $e) {
    json_response([
        "success" => false,
        "message" => "Database connection failed"
    ], 500);
}

function get_json_body() {
    $raw = file_get_contents("php://input");
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

function base64url_encode($data) {
    return rtrim(strtr(base64_encode($data), "+/", "-_"), "=");
}

function base64url_decode($data) {
    return base64_decode(strtr($data, "-_", "+/"));
}

function jwt_sign($payload, $secret) {
    $header = [
        "typ" => "JWT",
        "alg" => "HS256"
    ];

    $payload["exp"] = time() + (30 * 24 * 60 * 60);

    $header_encoded = base64url_encode(json_encode($header));
    $payload_encoded = base64url_encode(json_encode($payload));

    $signature = hash_hmac(
        "sha256",
        $header_encoded . "." . $payload_encoded,
        $secret,
        true
    );

    return $header_encoded . "." . $payload_encoded . "." . base64url_encode($signature);
}

function jwt_verify_token($token, $secret) {
    $parts = explode(".", $token);

    if (count($parts) !== 3) {
        return false;
    }

    [$header_encoded, $payload_encoded, $signature_encoded] = $parts;

    $signature_check = base64url_encode(
        hash_hmac(
            "sha256",
            $header_encoded . "." . $payload_encoded,
            $secret,
            true
        )
    );

    if (!hash_equals($signature_check, $signature_encoded)) {
        return false;
    }

    $payload = json_decode(base64url_decode($payload_encoded), true);

    if (!$payload) {
        return false;
    }

    if (isset($payload["exp"]) && time() > $payload["exp"]) {
        return false;
    }

    return $payload;
}

function get_auth_user() {
    global $JWT_SECRET;

    $headers = getallheaders();
    $auth_header = $headers["Authorization"] ?? $headers["authorization"] ?? "";

    if (!$auth_header) {
        json_response([
            "success" => false,
            "message" => "No token provided"
        ], 401);
    }

    $token = trim(str_replace("Bearer", "", $auth_header));
    $decoded = jwt_verify_token($token, $JWT_SECRET);

    if (!$decoded) {
        json_response([
            "success" => false,
            "message" => "Invalid token"
        ], 401);
    }

    return $decoded;
}

function require_admin($user) {
    if (($user["role"] ?? "") !== "admin") {
        json_response([
            "success" => false,
            "message" => "Admin only"
        ], 403);
    }
}

function recalculate_all_points() {
    global $pdo, $USERS_TABLE, $MATCHES_TABLE, $PREDICTIONS_TABLE;

    $pdo->query("UPDATE $USERS_TABLE SET points = 0");

    $stmt = $pdo->query("
        SELECT
            p.user_id,
            p.prediction,
            p.home_score AS predicted_home,
            p.away_score AS predicted_away,
            m.result,
            m.home_score AS actual_home,
            m.away_score AS actual_away,
            COALESCE(m.winner_points, 3) AS winner_points,
            COALESCE(m.perfect_points, 5) AS perfect_points,
            COALESCE(m.close_points, 1) AS close_points
        FROM $PREDICTIONS_TABLE p
        JOIN $MATCHES_TABLE m
        ON p.match_id = m.id
        WHERE m.status = 'finished'
        AND m.result IS NOT NULL
        AND m.home_score IS NOT NULL
        AND m.away_score IS NOT NULL
    ");

    $rows = $stmt->fetchAll();

    foreach ($rows as $row) {
    $points = 0;

    if ($row["prediction"] === $row["result"]) {
        $winnerPoints = (int)$row["winner_points"];

if ($row["result"] === "Draw") {
    $winnerPoints = $winnerPoints * 2;
}

$points += $winnerPoints;

        if (
            (int)$row["predicted_home"] === (int)$row["actual_home"] &&
            (int)$row["predicted_away"] === (int)$row["actual_away"]
        ) {
            $points += (int)$row["perfect_points"];
        } else {
            $homeDiff = abs(
                (int)$row["predicted_home"] -
                (int)$row["actual_home"]
            );

            $awayDiff = abs(
                (int)$row["predicted_away"] -
                (int)$row["actual_away"]
            );

            if ($homeDiff <= 1 && $awayDiff <= 1) {
                $points += (int)$row["close_points"];
            }
        }
    }

    if ($points > 0) {
        $update = $pdo->prepare("
            UPDATE $USERS_TABLE
            SET points = points + ?
            WHERE id = ?
        ");

        $update->execute([
            $points,
            $row["user_id"]
        ]);
    }
}
}

$method = $_SERVER["REQUEST_METHOD"];
$path = parse_url($_SERVER["REQUEST_URI"], PHP_URL_PATH);
$path = preg_replace("#^/fifa#", "", $path);

if ($path === "" || $path === "/") {
    json_response([
        "success" => true,
        "message" => "MinersHub Football API Running"
    ]);
}

$body = get_json_body();

/*
|--------------------------------------------------------------------------
| AUTH
|--------------------------------------------------------------------------
*/

if ($method === "POST" && $path === "/api/auth/register") {
    global $pdo, $USERS_TABLE;

    $name = trim($body["name"] ?? "");
    $twitter_url = trim($body["twitter_url"] ?? "");
    $email = trim($body["email"] ?? "");
    $password = $body["password"] ?? "";

    if ($name === "" || $twitter_url === "" || $email === "" || $password === "") {
        json_response([
            "success" => false,
            "message" => "All fields are required"
        ], 400);
    }

    $stmt = $pdo->prepare("SELECT id FROM $USERS_TABLE WHERE email = ?");
    $stmt->execute([$email]);

    if ($stmt->fetch()) {
        json_response([
            "success" => false,
            "message" => "Email already registered"
        ], 400);
    }

    $hashedPassword = password_hash($password, PASSWORD_BCRYPT);

    $stmt = $pdo->prepare("
        INSERT INTO $USERS_TABLE
        (name, twitter_url, email, password, role, status, points)
        VALUES (?, ?, ?, ?, 'user', 'pending', 0)
    ");

    $stmt->execute([
        $name,
        $twitter_url,
        $email,
        $hashedPassword
    ]);

    json_response([
        "success" => true,
        "message" => "Registration successful. Waiting for approval."
    ], 201);
}

if ($method === "POST" && $path === "/api/auth/login") {
    global $pdo, $USERS_TABLE, $JWT_SECRET;

    $email = trim($body["email"] ?? "");
    $password = $body["password"] ?? "";

    $stmt = $pdo->prepare("SELECT * FROM $USERS_TABLE WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();

    if (!$user || !password_verify($password, $user["password"])) {
        json_response([
            "success" => false,
            "message" => "Invalid email or password"
        ], 400);
    }

    if ($user["status"] === "rejected") {
        json_response([
            "success" => false,
            "message" => "Your account is currently rejected."
        ], 403);
    }

    if ($user["status"] === "pending") {
        json_response([
            "success" => false,
            "message" => "Your account is awaiting admin approval."
        ], 403);
    }

    $token = jwt_sign([
        "id" => $user["id"],
        "role" => $user["role"]
    ], $JWT_SECRET);

    json_response([
        "success" => true,
        "token" => $token,
        "user" => [
            "id" => $user["id"],
            "name" => $user["name"],
            "email" => $user["email"],
            "twitter_url" => $user["twitter_url"],
            "role" => $user["role"],
            "status" => $user["status"],
            "points" => $user["points"]
        ]
    ]);
}

if ($method === "GET" && $path === "/api/auth/me") {
    $authUser = get_auth_user();

    json_response([
        "success" => true,
        "user" => $authUser
    ]);
}

/*
|--------------------------------------------------------------------------
| ADMIN USERS
|--------------------------------------------------------------------------
*/

if ($method === "GET" && $path === "/api/admin/pending-users") {
    global $pdo, $USERS_TABLE;

    $authUser = get_auth_user();
    require_admin($authUser);

    $stmt = $pdo->query("
        SELECT id, name, email, twitter_url, created_at
        FROM $USERS_TABLE
        WHERE status='pending'
        ORDER BY created_at DESC
    ");

    json_response([
        "success" => true,
        "users" => $stmt->fetchAll()
    ]);
}

if ($method === "POST" && preg_match("#^/api/admin/approve-user/(\d+)$#", $path, $m)) {
    global $pdo, $USERS_TABLE;

    $authUser = get_auth_user();
    require_admin($authUser);

    $stmt = $pdo->prepare("
        UPDATE $USERS_TABLE
        SET status='approved'
        WHERE id=?
    ");

    $stmt->execute([$m[1]]);

    json_response([
        "success" => true,
        "message" => "User approved"
    ]);
}

if ($method === "POST" && preg_match("#^/api/admin/reject-user/(\d+)$#", $path, $m)) {
    global $pdo, $USERS_TABLE;

    $authUser = get_auth_user();
    require_admin($authUser);

    $stmt = $pdo->prepare("
        UPDATE $USERS_TABLE
        SET status='rejected'
        WHERE id=?
    ");

    $stmt->execute([$m[1]]);

    json_response([
        "success" => true,
        "message" => "User rejected. Points are preserved."
    ]);
}

if ($method === "GET" && $path === "/api/admin/users") {
    global $pdo, $USERS_TABLE;

    $authUser = get_auth_user();
    require_admin($authUser);

    $stmt = $pdo->query("
        SELECT
            id,
            name,
            email,
            twitter_url,
            status,
            points,
            created_at
        FROM $USERS_TABLE
        ORDER BY created_at DESC
    ");

    json_response([
        "success" => true,
        "users" => $stmt->fetchAll()
    ]);
}

/*
|--------------------------------------------------------------------------
| ADMIN MATCHES
|--------------------------------------------------------------------------
*/

if ($method === "POST" && $path === "/api/admin/matches") {
    global $pdo, $MATCHES_TABLE;

    $authUser = get_auth_user();
    require_admin($authUser);

    $home_team = trim($body["home_team"] ?? "");
    $away_team = trim($body["away_team"] ?? "");
    $kickoff_time = $body["kickoff_time"] ?? "";

    if ($home_team === "") {
        json_response([
            "success" => false,
            "message" => "Home team is required"
        ], 400);
    }

    if ($away_team === "") {
        json_response([
            "success" => false,
            "message" => "Away team is required"
        ], 400);
    }

    if ($kickoff_time === "") {
        json_response([
            "success" => false,
            "message" => "Kickoff date and time is required"
        ], 400);
    }

    $stmt = $pdo->prepare("
        INSERT INTO $MATCHES_TABLE
        (
            home_team,
            away_team,
            kickoff_time,
            status,
            winner_points,
            perfect_points,
            close_points
        )
        VALUES (?, ?, ?, 'scheduled', ?, ?, ?)
    ");

    $stmt->execute([
        $home_team,
        $away_team,
        $kickoff_time,
        $body["winner_points"] ?? null,
        $body["perfect_points"] ?? null,
        $body["close_points"] ?? null
    ]);

    json_response([
        "success" => true,
        "message" => "Match created successfully"
    ]);
}

if ($method === "GET" && $path === "/api/admin/matches") {
    global $pdo, $MATCHES_TABLE, $PREDICTIONS_TABLE;

    $authUser = get_auth_user();
    require_admin($authUser);

    $stmt = $pdo->query("
        SELECT
            m.*,

            (
                SELECT COUNT(*)
                FROM $PREDICTIONS_TABLE p
                WHERE p.match_id = m.id
            ) AS total_predictions,

            (
                SELECT COUNT(*)
                FROM $PREDICTIONS_TABLE p
                WHERE p.match_id = m.id
                AND p.prediction = m.home_team
            ) AS home_votes,

            (
                SELECT COUNT(*)
                FROM $PREDICTIONS_TABLE p
                WHERE p.match_id = m.id
                AND p.prediction = m.away_team
            ) AS away_votes,

            (
                SELECT COUNT(*)
                FROM $PREDICTIONS_TABLE p
                WHERE p.match_id = m.id
                AND p.prediction = 'Draw'
            ) AS draw_votes

        FROM $MATCHES_TABLE m
        ORDER BY kickoff_time DESC
    ");

    json_response([
        "success" => true,
        "matches" => $stmt->fetchAll()
    ]);
}

if ($method === "POST" && preg_match("#^/api/admin/match-result/(\d+)$#", $path, $m)) {
    global $pdo, $MATCHES_TABLE;

    $authUser = get_auth_user();
    require_admin($authUser);

    $matchId = $m[1];

    if (!isset($body["home_score"]) || !isset($body["away_score"])) {
        json_response([
            "success" => false,
            "message" => "Final score is required"
        ], 400);
    }

    $home_score = (int)$body["home_score"];
    $away_score = (int)$body["away_score"];

    if ($home_score < 0 || $away_score < 0) {
        json_response([
            "success" => false,
            "message" => "Score cannot be negative"
        ], 400);
    }

    $stmt = $pdo->prepare("SELECT * FROM $MATCHES_TABLE WHERE id = ?");
    $stmt->execute([$matchId]);
    $match = $stmt->fetch();

    if (!$match) {
        json_response([
            "success" => false,
            "message" => "Match not found"
        ], 404);
    }

    $winner = "Draw";

    if ($home_score > $away_score) {
        $winner = $match["home_team"];
    }

    if ($away_score > $home_score) {
        $winner = $match["away_team"];
    }

    $stmt = $pdo->prepare("
        UPDATE $MATCHES_TABLE
        SET
            result = ?,
            home_score = ?,
            away_score = ?,
            status = 'finished'
        WHERE id = ?
    ");

    $stmt->execute([
        $winner,
        $home_score,
        $away_score,
        $matchId
    ]);

    recalculate_all_points();

    json_response([
        "success" => true,
        "winner" => $winner,
        "message" => "Result updated and points recalculated"
    ]);
}

if ($method === "DELETE" && preg_match("#^/api/admin/matches/(\d+)$#", $path, $m)) {
    global $pdo, $MATCHES_TABLE, $PREDICTIONS_TABLE;

    $authUser = get_auth_user();
    require_admin($authUser);

    $matchId = $m[1];

    $stmt = $pdo->prepare("SELECT id FROM $MATCHES_TABLE WHERE id = ?");
    $stmt->execute([$matchId]);

    if (!$stmt->fetch()) {
        json_response([
            "success" => false,
            "message" => "Match not found"
        ], 404);
    }

    $stmt = $pdo->prepare("DELETE FROM $PREDICTIONS_TABLE WHERE match_id = ?");
    $stmt->execute([$matchId]);

    $stmt = $pdo->prepare("DELETE FROM $MATCHES_TABLE WHERE id = ?");
    $stmt->execute([$matchId]);

    recalculate_all_points();

    json_response([
        "success" => true,
        "message" => "Match, predictions, and related points deleted"
    ]);
}

if ($method === "PUT" && preg_match("#^/api/admin/matches/(\d+)$#", $path, $m)) {
    global $pdo, $MATCHES_TABLE, $PREDICTIONS_TABLE;

    $authUser = get_auth_user();
    require_admin($authUser);

    $matchId = $m[1];

    $stmt = $pdo->prepare("
        SELECT COUNT(*) AS total
        FROM $PREDICTIONS_TABLE
        WHERE match_id = ?
    ");

    $stmt->execute([$matchId]);
    $predictionRows = $stmt->fetch();
    $totalPredictions = (int)$predictionRows["total"];

    $stmt = $pdo->prepare("SELECT * FROM $MATCHES_TABLE WHERE id = ?");
    $stmt->execute([$matchId]);
    $match = $stmt->fetch();

    if (!$match) {
        json_response([
            "success" => false,
            "message" => "Match not found"
        ], 404);
    }

    $home_team = trim($body["home_team"] ?? "");
    $away_team = trim($body["away_team"] ?? "");
    $kickoff_time = $body["kickoff_time"] ?? null;
    $status = $body["status"] ?? "scheduled";

    if ($home_team === "" || $away_team === "" || !$kickoff_time) {
        json_response([
            "success" => false,
            "message" => "Home team, away team, and kickoff time are required"
        ], 400);
    }

    if (
        $totalPredictions > 0 &&
        (
            $home_team !== $match["home_team"] ||
            $away_team !== $match["away_team"]
        )
    ) {
        json_response([
            "success" => false,
            "message" => "Cannot change team names after predictions exist"
        ], 400);
    }

    $stmt = $pdo->prepare("
        UPDATE $MATCHES_TABLE
        SET
            home_team = ?,
            away_team = ?,
            kickoff_time = ?,
            status = ?
        WHERE id = ?
    ");

    $stmt->execute([
        $home_team,
        $away_team,
        $kickoff_time,
        $status,
        $matchId
    ]);

    recalculate_all_points();

    json_response([
        "success" => true,
        "message" => "Match updated"
    ]);
}

if ($method === "GET" && preg_match("#^/api/admin/match-predictions/(\d+)$#", $path, $m)) {
    global $pdo, $USERS_TABLE, $PREDICTIONS_TABLE;

    $authUser = get_auth_user();
    require_admin($authUser);

    $stmt = $pdo->prepare("
        SELECT
            p.*,
            u.name
        FROM $PREDICTIONS_TABLE p
        JOIN $USERS_TABLE u
        ON p.user_id = u.id
        WHERE p.match_id = ?
        ORDER BY u.name ASC
    ");

    $stmt->execute([$m[1]]);

    json_response([
        "success" => true,
        "predictions" => $stmt->fetchAll()
    ]);
}

/*
|--------------------------------------------------------------------------
| ADMIN STATS + PROFILE
|--------------------------------------------------------------------------
*/

if ($method === "GET" && $path === "/api/admin/stats") {
    global $pdo, $USERS_TABLE, $MATCHES_TABLE, $PREDICTIONS_TABLE;

    $authUser = get_auth_user();
    require_admin($authUser);

    $users = $pdo->query("SELECT COUNT(*) AS total FROM $USERS_TABLE")->fetch();
    $pendingUsers = $pdo->query("SELECT COUNT(*) AS total FROM $USERS_TABLE WHERE status='pending'")->fetch();
    $matches = $pdo->query("SELECT COUNT(*) AS total FROM $MATCHES_TABLE")->fetch();
    $scheduledMatches = $pdo->query("SELECT COUNT(*) AS total FROM $MATCHES_TABLE WHERE status='scheduled'")->fetch();
    $finishedMatches = $pdo->query("SELECT COUNT(*) AS total FROM $MATCHES_TABLE WHERE status='finished'")->fetch();
    $predictions = $pdo->query("SELECT COUNT(*) AS total FROM $PREDICTIONS_TABLE")->fetch();
    $points = $pdo->query("SELECT COALESCE(SUM(points), 0) AS total FROM $USERS_TABLE")->fetch();

    json_response([
        "success" => true,
        "stats" => [
            "users" => $users["total"],
            "pendingUsers" => $pendingUsers["total"],
            "matches" => $matches["total"],
            "scheduledMatches" => $scheduledMatches["total"],
            "finishedMatches" => $finishedMatches["total"],
            "predictions" => $predictions["total"],
            "points" => $points["total"]
        ]
    ]);
}

if ($method === "GET" && preg_match("#^/api/admin/user-profile/(\d+)$#", $path, $m)) {
    global $pdo, $USERS_TABLE, $MATCHES_TABLE, $PREDICTIONS_TABLE;

    $authUser = get_auth_user();
    require_admin($authUser);

    $userId = $m[1];

    $stmt = $pdo->prepare("
        SELECT
            id,
            name,
            email,
            twitter_url,
            status,
            points,
            created_at
        FROM $USERS_TABLE
        WHERE id = ?
    ");

    $stmt->execute([$userId]);
    $user = $stmt->fetch();

    if (!$user) {
        json_response([
            "success" => false,
            "message" => "User not found"
        ], 404);
    }

    $stmt = $pdo->prepare("
        SELECT
            p.*,
            m.home_team,
            m.away_team,
            m.result,
            m.home_score AS actual_home_score,
            m.away_score AS actual_away_score,
            m.winner_points,
            m.perfect_points,
            m.close_points
        FROM $PREDICTIONS_TABLE p
        JOIN $MATCHES_TABLE m
        ON p.match_id = m.id
        WHERE p.user_id = ?
        ORDER BY p.created_at DESC
    ");

    $stmt->execute([$userId]);

    json_response([
        "success" => true,
        "user" => $user,
        "predictions" => $stmt->fetchAll()
    ]);
}

/*
|--------------------------------------------------------------------------
| FOOTBALL PUBLIC/USER ROUTES
|--------------------------------------------------------------------------
*/

if ($method === "GET" && $path === "/api/football/matches") {
    global $pdo, $MATCHES_TABLE;

    $stmt = $pdo->query("
        SELECT *
        FROM $MATCHES_TABLE
        WHERE status = 'scheduled'
        ORDER BY kickoff_time ASC
    ");

    json_response([
        "success" => true,
        "matches" => $stmt->fetchAll()
    ]);
}

if ($method === "POST" && $path === "/api/football/predict") {
    global $pdo, $MATCHES_TABLE, $PREDICTIONS_TABLE;

    $authUser = get_auth_user();

    $match_id = $body["match_id"] ?? null;
    $prediction = $body["prediction"] ?? "";

    if (!isset($body["home_score"]) || !isset($body["away_score"])) {
        json_response([
            "success" => false,
            "message" => "Score prediction is required"
        ], 400);
    }

    $home_score = (int)$body["home_score"];
    $away_score = (int)$body["away_score"];

    $stmt = $pdo->prepare("SELECT * FROM $MATCHES_TABLE WHERE id = ?");
    $stmt->execute([$match_id]);
    $match = $stmt->fetch();

    if (!$match) {
        json_response([
            "success" => false,
            "message" => "Match not found"
        ], 404);
    }

    if ($match["status"] !== "scheduled") {
        json_response([
            "success" => false,
            "message" => "Prediction closed"
        ], 400);
    }

    $stmt = $pdo->prepare("
        SELECT id
        FROM $PREDICTIONS_TABLE
        WHERE user_id = ?
        AND match_id = ?
    ");

    $stmt->execute([
        $authUser["id"],
        $match_id
    ]);

    if ($stmt->fetch()) {
        json_response([
            "success" => false,
            "message" => "You already predicted this match"
        ], 400);
    }

    if ($home_score < 0 || $away_score < 0) {
        json_response([
            "success" => false,
            "message" => "Score cannot be negative"
        ], 400);
    }

    if ($prediction === $match["home_team"] && $home_score <= $away_score) {
        json_response([
            "success" => false,
            "message" => "Score does not match selected winner"
        ], 400);
    }

    if ($prediction === $match["away_team"] && $away_score <= $home_score) {
        json_response([
            "success" => false,
            "message" => "Score does not match selected winner"
        ], 400);
    }

    if ($prediction === "Draw" && $home_score !== $away_score) {
        json_response([
            "success" => false,
            "message" => "Draw prediction requires equal scores"
        ], 400);
    }

    $kickoff = strtotime($match["kickoff_time"]);

    if (time() >= $kickoff) {
        json_response([
            "success" => false,
            "message" => "Prediction closed"
        ], 400);
    }

    $stmt = $pdo->prepare("
        INSERT INTO $PREDICTIONS_TABLE
        (
            user_id,
            match_id,
            prediction,
            home_score,
            away_score
        )
        VALUES (?, ?, ?, ?, ?)
    ");

    $stmt->execute([
        $authUser["id"],
        $match_id,
        $prediction,
        $home_score,
        $away_score
    ]);

    json_response([
        "success" => true,
        "message" => "Prediction submitted"
    ]);
}

if ($method === "GET" && $path === "/api/football/my-predictions") {
    global $pdo, $MATCHES_TABLE, $PREDICTIONS_TABLE;

    $authUser = get_auth_user();

$stmt = $pdo->prepare("
        SELECT
            p.*,
            m.home_team,
            m.away_team,
            m.kickoff_time,
            m.result,
            m.status,
            m.home_score AS final_home_score,
            m.away_score AS final_away_score,
            m.winner_points,
            m.perfect_points,
            m.close_points
        FROM $PREDICTIONS_TABLE p
        JOIN $MATCHES_TABLE m
        ON p.match_id = m.id
        WHERE p.user_id = ?
        ORDER BY p.created_at DESC
    ");

    $stmt->execute([$authUser["id"]]);

    json_response([
        "success" => true,
        "predictions" => $stmt->fetchAll()
    ]);
}
if ($method === "GET" && preg_match("#^/api/football/match-predictions/(\d+)$#", $path, $m)) {
    global $pdo, $USERS_TABLE, $PREDICTIONS_TABLE;

    $stmt = $pdo->prepare("
        SELECT
            u.name,
            p.prediction,
            p.home_score,
            p.away_score,
            p.created_at
        FROM $PREDICTIONS_TABLE p
        JOIN $USERS_TABLE u
        ON p.user_id = u.id
        WHERE p.match_id = ?
        AND u.status = 'approved'
        ORDER BY p.created_at ASC
    ");

    $stmt->execute([$m[1]]);

    json_response([
        "success" => true,
        "predictions" => $stmt->fetchAll()
    ]);
}

if ($method === "GET" && $path === "/api/football/leaderboard") {
    global $pdo, $USERS_TABLE, $MATCHES_TABLE, $PREDICTIONS_TABLE;

    $stmt = $pdo->query("
        SELECT
            u.id,
            u.name,
            u.points,
            u.profile_image,

            (
                SELECT COUNT(*)
                FROM $PREDICTIONS_TABLE p
                JOIN $MATCHES_TABLE m
                ON p.match_id = m.id
                WHERE
                    p.user_id = u.id
                    AND m.status = 'finished'
                    AND p.prediction = m.result
            ) AS correct_predictions,

            (
                SELECT COUNT(*)
                FROM $PREDICTIONS_TABLE p
                JOIN $MATCHES_TABLE m
                ON p.match_id = m.id
                WHERE
                    p.user_id = u.id
                    AND m.status = 'finished'
                    AND p.prediction = m.result
                    AND p.home_score = m.home_score
                    AND p.away_score = m.away_score
            ) AS perfect_scores

        FROM $USERS_TABLE u
        WHERE u.status = 'approved'
        ORDER BY
            u.points DESC,
            correct_predictions DESC,
            perfect_scores DESC,
            u.id ASC
            
        LIMIT 100
    ");

    json_response([
        "success" => true,
        "users" => $stmt->fetchAll()
    ]);
}

if ($method === "GET" && $path === "/api/football/profile") {
    global $pdo, $USERS_TABLE, $MATCHES_TABLE, $PREDICTIONS_TABLE;

    $authUser = get_auth_user();
    $userId = $authUser["id"];

    $stmt = $pdo->prepare("
        SELECT
            id,
            name,
            points,
            profile_image
        FROM $USERS_TABLE
        WHERE id = ?
    ");

    $stmt->execute([$userId]);
    $user = $stmt->fetch();

    if (!$user) {
        json_response([
            "success" => false,
            "message" => "User not found"
        ], 404);
    }

    $stmt = $pdo->prepare("
        SELECT COUNT(*) total
        FROM $PREDICTIONS_TABLE
        WHERE user_id = ?
    ");
    $stmt->execute([$userId]);
    $predictionCount = $stmt->fetch();

    $stmt = $pdo->prepare("
        SELECT COUNT(*) total
        FROM $PREDICTIONS_TABLE p
        JOIN $MATCHES_TABLE m
        ON p.match_id = m.id
        WHERE
            p.user_id = ?
            AND m.status = 'finished'
            AND p.prediction = m.result
    ");
    $stmt->execute([$userId]);
    $correctCount = $stmt->fetch();

    $stmt = $pdo->prepare("
        SELECT COUNT(*) total
        FROM $PREDICTIONS_TABLE p
        JOIN $MATCHES_TABLE m
        ON p.match_id = m.id
        WHERE
            p.user_id = ?
            AND m.status = 'finished'
            AND p.prediction = m.result
            AND p.home_score = m.home_score
            AND p.away_score = m.away_score
    ");
    $stmt->execute([$userId]);
    $perfectCount = $stmt->fetch();
    
    $stmt = $pdo->prepare("
    SELECT COUNT(*) AS total
    FROM $PREDICTIONS_TABLE p
    JOIN $MATCHES_TABLE m
    ON p.match_id = m.id
    WHERE
        p.user_id = ?
        AND m.status = 'finished'
        AND p.prediction = m.result
        AND NOT (
            p.home_score = m.home_score
            AND p.away_score = m.away_score
        )
        AND ABS(p.home_score - m.home_score) <= 1
        AND ABS(p.away_score - m.away_score) <= 1
");
$stmt->execute([$userId]);
$closeCount = $stmt->fetch();


    $stmt = $pdo->prepare("
        SELECT COUNT(*) total
        FROM $PREDICTIONS_TABLE p
        JOIN $MATCHES_TABLE m
        ON p.match_id = m.id
        WHERE
            p.user_id = ?
            AND m.status = 'finished'
            AND p.prediction = m.result
            AND NOT (
                p.home_score = m.home_score
                AND p.away_score = m.away_score
            )
            AND ABS(p.home_score - m.home_score) <= 1
            AND ABS(p.away_score - m.away_score) <= 1
    ");
    $stmt->execute([$userId]);
    $closeCount = $stmt->fetch();
    
    $stmt = $pdo->prepare("
    SELECT COUNT(*) total
    FROM $PREDICTIONS_TABLE p
    JOIN $MATCHES_TABLE m
    ON p.match_id = m.id
    WHERE
        p.user_id = ?
        AND m.status = 'finished'
        AND m.result IS NOT NULL
        AND p.prediction != m.result
");
$stmt->execute([$userId]);
$wrongCount = $stmt->fetch();



    $total = (int)$predictionCount["total"];
$correct = (int)$correctCount["total"];
$wrong = (int)$wrongCount["total"];
$finished = $correct + $wrong;
$pending = $total - $finished;

$accuracy = $finished > 0
    ? number_format(($correct / $finished) * 100, 2, ".", "")
    : 0;

    $achievements = [];

    if ($user["points"] >= 10) $achievements[] = "⭐ Getting Started";
    if ($total >= 10) $achievements[] = "⚽ Rising Predictor";
    if ($total >= 50) $achievements[] = "⚽ Veteran Predictor";
    if ($correct >= 25) $achievements[] = "🏆 Winner Hunter";
    if ($correct >= 50) $achievements[] = "🏆 Prediction Master";
    if ($perfectCount["total"] >= 5) $achievements[] = "🎯 Perfect Predictor";
    if ($perfectCount["total"] >= 15) $achievements[] = "🎯 Oracle";
    if ($user["points"] >= 50) $achievements[] = "👑 Top Predictor";
    if ($user["points"] >= 100) $achievements[] = "👑 Elite Analyst";
    if ($accuracy >= 70) $achievements[] = "🔥 High Accuracy";
    if ($accuracy >= 85) $achievements[] = "🔥 Prediction Machine";

    json_response([
        "success" => true,
        "user" => $user,
        "stats" => [
            "predictions" => $total,
            "correct" => $correct,
            "wrong" => $wrong,
            "pending" => $pending,
            "perfect" => $perfectCount["total"],
            "close" => $closeCount["total"],
            "accuracy" => $accuracy,
            "achievements" => $achievements
        ]
    ]);
}

if ($method === "POST" && $path === "/api/football/profile-image") {
    global $pdo, $USERS_TABLE;

    $authUser = get_auth_user();
    $userId = $authUser["id"];

    if (!isset($_FILES["profile_image"])) {
        json_response([
            "success" => false,
            "message" => "No image uploaded"
        ], 400);
    }

    $file = $_FILES["profile_image"];

    if ($file["size"] > 400 * 1024) {
        json_response([
            "success" => false,
            "message" => "Image must be under 400KB"
        ], 400);
    }

    $allowedTypes = ["image/jpeg", "image/png", "image/webp"];

    if (!in_array($file["type"], $allowedTypes, true)) {
        json_response([
            "success" => false,
            "message" => "Only JPG, PNG, or WEBP allowed"
        ], 400);
    }

    $ext = pathinfo($file["name"], PATHINFO_EXTENSION);
    $fileName = "user_" . $userId . "_" . time() . "." . $ext;

    $uploadDir = __DIR__ . "/uploads/profile/";

    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }

    $targetPath = $uploadDir . $fileName;

    if (!move_uploaded_file($file["tmp_name"], $targetPath)) {
        json_response([
            "success" => false,
            "message" => "Failed to upload image"
        ], 500);
    }

// Fetch old profile image
$stmt = $pdo->prepare("
    SELECT profile_image
    FROM $USERS_TABLE
    WHERE id = ?
");
$stmt->execute([$userId]);

$oldUser = $stmt->fetch();

    $imageUrl = "/uploads/profile/" . $fileName;
    
    // Delete previous image if it exists
if (
    !empty($oldUser["profile_image"])
) {
    $oldPath = __DIR__ . $oldUser["profile_image"];

    if (file_exists($oldPath)) {
        unlink($oldPath);
    }
}

    $stmt = $pdo->prepare("
        UPDATE $USERS_TABLE
        SET profile_image = ?
        WHERE id = ?
    ");

    $stmt->execute([$imageUrl, $userId]);

    json_response([
        "success" => true,
        "profile_image" => $imageUrl,
        "message" => "Profile image updated"
    ]);
}

/*
|--------------------------------------------------------------------------
| PUBLIC USER ROUTES
|--------------------------------------------------------------------------
*/

if ($method === "GET" && preg_match("#^/api/users/(\d+)$#", $path, $m)) {
    global $pdo, $USERS_TABLE;

    $stmt = $pdo->prepare("
        SELECT
            id,
            name,
            twitter_url,
            points,
            profile_image,
            created_at
        FROM $USERS_TABLE
        WHERE id = ?
        AND status = 'approved'
    ");

    $stmt->execute([$m[1]]);
    $user = $stmt->fetch();

    if (!$user) {
        json_response([
            "success" => false,
            "message" => "User not found"
        ], 404);
    }

    json_response([
        "success" => true,
        "user" => $user
    ]);
}

if ($method === "GET" && preg_match("#^/api/users/(\d+)/predictions$#", $path, $m)) {
    global $pdo, $MATCHES_TABLE, $PREDICTIONS_TABLE, $USERS_TABLE;

    $stmt = $pdo->prepare("
        SELECT id
        FROM $USERS_TABLE
        WHERE id = ?
        AND status = 'approved'
    ");
    $stmt->execute([$m[1]]);

    if (!$stmt->fetch()) {
        json_response([
            "success" => false,
            "message" => "User not found"
        ], 404);
    }

$stmt = $pdo->prepare("
        SELECT
    p.*,
    m.home_team,
    m.away_team,
    m.result,
    m.status,
    m.home_score AS final_home_score,
    m.away_score AS final_away_score,
    m.winner_points,
    m.perfect_points,
    m.close_points
        FROM $PREDICTIONS_TABLE p
        JOIN $MATCHES_TABLE m
        ON p.match_id = m.id
        WHERE p.user_id = ?
        ORDER BY p.created_at DESC
    ");

    $stmt->execute([$m[1]]);

    json_response([
        "success" => true,
        "predictions" => $stmt->fetchAll()
    ]);
}

if ($method === "GET" && preg_match("#^/api/users/(\d+)/stats$#", $path, $m)) {
    global $pdo, $MATCHES_TABLE, $PREDICTIONS_TABLE, $USERS_TABLE;

    $userId = $m[1];

    $stmt = $pdo->prepare("
        SELECT id
        FROM $USERS_TABLE
        WHERE id = ?
        AND status = 'approved'
    ");
    $stmt->execute([$userId]);

    if (!$stmt->fetch()) {
        json_response([
            "success" => false,
            "message" => "User not found"
        ], 404);
    }

    $stmt = $pdo->prepare("
        SELECT COUNT(*) AS total
        FROM $PREDICTIONS_TABLE
        WHERE user_id = ?
    ");
    $stmt->execute([$userId]);
    $predictionCount = $stmt->fetch();

    $stmt = $pdo->prepare("
        SELECT COUNT(*) AS total
        FROM $PREDICTIONS_TABLE p
        JOIN $MATCHES_TABLE m
        ON p.match_id = m.id
        WHERE
            p.user_id = ?
            AND m.status = 'finished'
            AND p.prediction = m.result
    ");
    $stmt->execute([$userId]);
    $correctCount = $stmt->fetch();

    $stmt = $pdo->prepare("
        SELECT COUNT(*) AS total
        FROM $PREDICTIONS_TABLE p
        JOIN $MATCHES_TABLE m
        ON p.match_id = m.id
        WHERE
            p.user_id = ?
            AND m.status = 'finished'
            AND m.result IS NOT NULL
            AND p.prediction != m.result
    ");
    $stmt->execute([$userId]);
    $wrongCount = $stmt->fetch();

    $stmt = $pdo->prepare("
        SELECT COUNT(*) AS total
        FROM $PREDICTIONS_TABLE p
        JOIN $MATCHES_TABLE m
        ON p.match_id = m.id
        WHERE
            p.user_id = ?
            AND m.status = 'finished'
            AND p.prediction = m.result
            AND p.home_score = m.home_score
            AND p.away_score = m.away_score
    ");
    $stmt->execute([$userId]);
    $perfectCount = $stmt->fetch();
    
    $stmt = $pdo->prepare("
    SELECT COUNT(*) AS total
    FROM $PREDICTIONS_TABLE p
    JOIN $MATCHES_TABLE m
    ON p.match_id = m.id
    WHERE
        p.user_id = ?
        AND m.status = 'finished'
        AND p.prediction = m.result
        AND NOT (
            p.home_score = m.home_score
            AND p.away_score = m.away_score
        )
        AND ABS(p.home_score - m.home_score) <= 1
        AND ABS(p.away_score - m.away_score) <= 1
");
$stmt->execute([$userId]);
$closeCount = $stmt->fetch();


    $total = (int)$predictionCount["total"];
    $correct = (int)$correctCount["total"];
    $wrong = (int)$wrongCount["total"];
    $finished = $correct + $wrong;
    $pending = $total - $finished;

    $accuracy = $finished > 0
        ? number_format(($correct / $finished) * 100, 2, ".", "")
        : 0;

    json_response([
        "success" => true,
        "stats" => [
            "total_predictions" => $total,
            "correct_predictions" => $correct,
            "wrong_predictions" => $wrong,
            "pending_predictions" => $pending,
"perfect_scores" => (int)$perfectCount["total"],
"close_scores" => (int)$closeCount["total"],
"accuracy" => $accuracy
        ]
    ]);
}

if ($method === "GET" && preg_match("#^/api/users/(\d+)/rank$#", $path, $m)) {
    global $pdo, $USERS_TABLE, $MATCHES_TABLE, $PREDICTIONS_TABLE;

$stmt = $pdo->query("
    SELECT
        u.id,
        u.points,

        (
            SELECT COUNT(*)
            FROM $PREDICTIONS_TABLE p
            JOIN $MATCHES_TABLE m
            ON p.match_id = m.id
            WHERE
                p.user_id = u.id
                AND m.status = 'finished'
                AND p.prediction = m.result
        ) AS correct_predictions,

        (
            SELECT COUNT(*)
            FROM $PREDICTIONS_TABLE p
            JOIN $MATCHES_TABLE m
            ON p.match_id = m.id
            WHERE
                p.user_id = u.id
                AND m.status = 'finished'
                AND p.prediction = m.result
                AND p.home_score = m.home_score
                AND p.away_score = m.away_score
        ) AS perfect_scores

    FROM $USERS_TABLE u
    WHERE u.status='approved'
    ORDER BY
        u.points DESC,
        correct_predictions DESC,
        perfect_scores DESC,
        u.id ASC
");

    $users = $stmt->fetchAll();
    $rank = 0;

    foreach ($users as $index => $user) {
        if ((int)$user["id"] === (int)$m[1]) {
            $rank = $index + 1;
            break;
        }
    }

    json_response([
        "success" => true,
        "rank" => $rank
    ]);
}

json_response([
    "success" => false,
    "message" => "Route not found",
    "path" => $path
], 404);