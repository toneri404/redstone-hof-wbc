<?php
echo "pong";